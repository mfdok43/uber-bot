import {TGCommand} from "./tg-command.class";
import {Scenes} from "telegraf";
import {BackButton, CreatePostButton, ChannelsMenu, UsersMenu} from "./markup.buttons";
import {IConfigService} from "../../config/config.interface";
import {ConfigService} from "../../config/config.service";
import axios from "axios";

const setSmile = (obj: any, smile: any) => {
    console.log(obj)
    obj = smile
    console.log(obj)

}

export class CreatePostScene extends TGCommand{
    scene: any
    channelsButtons: any
    backButton: any
    createPostButton: any
    replyMarkup: any
    // private readonly token: any
    constructor(bot: any) {

        super(bot)
        this.scene = new Scenes.BaseScene('createPost')
    }

    init () {
        console.log('scene init')
        this.scene.enter(async (ctx: any) => {
            ctx.scene.session.isText = `❌`
            ctx.scene.session.isLink = `❌`
            ctx.scene.session.isPhoto = `❌`
            ctx.scene.session.replyText = `Create post: text(!)${ctx.scene.session.isText} link${ctx.scene.session.isLink} photo${ctx.scene.session.isPhoto}`

            console.log('enter')
            this.channelsButtons = await new ChannelsMenu().buttonsMarkup().then((res: any) => res)

            this.backButton = new BackButton().markup
            this.createPostButton = new CreatePostButton().markup
            this.replyMarkup ={reply_markup: {inline_keyboard:
                        [...this.channelsButtons, this.createPostButton, this.backButton]
                }}

            ctx.reply(ctx.scene.session.replyText, this.replyMarkup)
        })

        this.scene.action(/-100/, (ctx: any) => {
           try {
               ctx.scene.session.sendChannelId = ctx.match.input
               console.log(ctx.match.input, 'chan')
           } catch (e) {
               console.log(e)
           }
        })


        this.scene.on('photo', (ctx: any) => {
            console.log(ctx.message.photo[0], 'photo')
            ctx.scene.session.photoId = ctx.message.photo[0].file_id
            ctx.scene.session.isPhoto = `✔️`
            ctx.scene.session.replyText = `Create post: text(!)${ctx.scene.session.isText} link${ctx.scene.session.isLink} photo${ctx.scene.session.isPhoto}`
            ctx.reply(ctx.scene.session.replyText, this.replyMarkup)
        })


        this.scene.hears(/t.me/, (ctx: any) => {
            ctx.scene.session.isLink = `✔️`
            ctx.scene.session.replyText = `Create post: text(!)${ctx.scene.session.isText} link${ctx.scene.session.isLink} photo${ctx.scene.session.isPhoto}`
            ctx.reply(ctx.scene.session.replyText, this.replyMarkup)
            ctx.scene.session.link = ctx.message.text
        })

        this.scene.on('message', async (ctx: any) => {
            this.channelsButtons = await new ChannelsMenu().buttonsMarkup().then((res: any) => res)
            console.log(this.channelsButtons, 'cnl')
            ctx.scene.session.messageText = ctx.message.text
            ctx.scene.session.isText = `✔️`
            ctx.scene.session.replyText = `Create post: text(!)${ctx.scene.session.isText} link${ctx.scene.session.isLink} photo${ctx.scene.session.isPhoto}`
            ctx.reply(ctx.scene.session.replyText, this.replyMarkup)

            console.log(ctx.message.text, ctx.scene.session.messageText, '1=1')
        })

        this.scene.action('createPost', (ctx: any) => {
            let cfg = new ConfigService()

            console.log(ctx.scene.session.link, 'lnk')

            const data = JSON.stringify({
                caption: ctx.scene.session.messageText,
                photo: ctx.scene.session.photoId.toString(),
                reply_markup: {inline_keyboard:
                        [[{ text: 'Connect with seller', url: ctx.scene.session.link }]]
                }
            })

            fetch(`https://api.telegram.org/bot${cfg.get("TELEGRAM_API_TOKEN")}/sendPhoto?chat_id=${ctx.scene.session.sendChannelId}`, {
                method: "POST",
                headers: {
                    "Connection": "close",
                    "Content-Type": "application/json",
                },
                body: data
            }).then(res => res.json()).then(res => console.log(res))

         })
    }
}
export class CreatePostCommand extends TGCommand{
    scene: any
    constructor(bot: any) {
        super(bot)
    }
    init() {
        try {
            this.bot.action('createPost', (ctx: any) => {
                ctx.scene.enter('createPost')
            })
        } catch (e) {
            console.log(e)
        }
    }
}
